package org.gdufs.servlet;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.gdufs.dao.StudentDao;
import org.gdufs.entity.Student;

public class StudentLogin extends HttpServlet {
	StudentDao studentDao = new StudentDao();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			Student student = null;
			DataInputStream ios = null;
			ios = new DataInputStream(request.getInputStream());
			ObjectOutputStream oos = null;
			oos = new ObjectOutputStream(response.getOutputStream());
			String studentId =  ios.readUTF();
			student = this.studentDao.findStudentById(studentId);
			if (student != null) {
				oos.writeObject(student);
			} else {
				student = new Student();
				student.setStudentId("fail");
				oos.writeObject(student);
			}
			oos.flush();
			oos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
		}

	}
}
