package org.gdufs.dao;

import java.sql.*;
import org.gdufs.entity.Student;
import org.gdufs.util.DBHelper;

@javax.jws.WebService(targetNamespace = "http://dao.gdufs.org/", serviceName = "StudentDaoService", portName = "StudentDaoPort")
public class StudentDaoDelegate {

	org.gdufs.dao.StudentDao studentDao = new org.gdufs.dao.StudentDao();

	public Student findStudentById(String studentId) {
		return studentDao.findStudentById(studentId);
	}

}