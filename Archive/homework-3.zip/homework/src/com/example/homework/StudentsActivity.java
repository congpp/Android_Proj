package com.example.homework;

import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.gdufs.entity.Student;

import com.example.util.WebFileService;

import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class StudentsActivity extends Activity {
	String ip = "192.168.1.102";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_students);
		networkPolicy();
		// ���Layout�����ListView
		ListView list = (ListView) findViewById(R.id.student_listView1);
		// ������������Item�Ͷ�̬�����Ӧ��Ԫ��
		SimpleAdapter listItemAdapter = new SimpleAdapter(
				this,
				getStudentsData(""),
				R.layout.student_item,
				new String[] { "img", "name", "id" },
				new int[] { R.id.studentItem_imageView1,
						R.id.studentItem_textView1, R.id.studentItem_textView2 });
		//�жϽ�Զ��ͼƬ����ת��ΪͼƬ��Դ
		  listItemAdapter.setViewBinder(new MyViewBinder());
		// ���Ӳ�����ʾ
		list.setAdapter(listItemAdapter);
		// ���ӵ�������
		list.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				Map<String, Object> clkmap = (Map<String, Object>) arg0
						.getItemAtPosition(arg2);
				setTitle(clkmap.get("name").toString());
			}
		});
	}

	// ���ɶ�ά��̬���飬����������
	private List<Map<String, Object>> getData() {
		ArrayList<Map<String, Object>> listitem = new ArrayList<Map<String, Object>>();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("img", R.drawable.girl);
		map.put("name", "��С��");
		map.put("id", "20130201023");
		listitem.add(map);

		map = new HashMap<String, Object>();
		map.put("img", R.drawable.boy);
		map.put("name", "���");
		map.put("id", "20130201024");
		listitem.add(map);

		map = new HashMap<String, Object>();
		map.put("img", R.drawable.boy);
		map.put("name", "���Ʒ�");
		map.put("id", "20130201025");
		listitem.add(map);

		map = new HashMap<String, Object>();
		map.put("img", R.drawable.girl);
		map.put("name", "����");
		map.put("id", "20130201026");
		listitem.add(map);

		return listitem;
	}

	private List<Map<String, Object>> getStudentsData(String str) {
		List<Map<String, Object>> mData = new ArrayList<Map<String, Object>>();
		// mData.clear();
		Map<String, Object> map = new HashMap<String, Object>();
		List<Student> students = getStudents(str);
		for (Student st : students) {
			map = new HashMap<String, Object>();
//			 if (st.getSex().trim().equals("m"))
//			 map.put("img", R.drawable.boy);
//			 else
//			 map.put("img", R.drawable.girl);
			// �������ϻ�ȡͼƬ
			if (st.getPhoto().contains("png")) {
				String address = "http://" + ip + ":8080/homeworkServer/photo/"
						+ st.getPhoto();
				byte[] data = WebFileService.getImage(address); // �õ�ͼƬ��������
				// ��������������λͼ
				Bitmap bit = BitmapFactory
						.decodeByteArray(data, 0, data.length);
				map.put("img", bit);
				
			} else if (st.getSex().trim().equals("m"))
				map.put("img", R.drawable.boy);
			else
				map.put("img", R.drawable.girl);
			//
			map.put("name", st.getStudentName());
			map.put("id", st.getStudentId());
			mData.add(map);
		}
		return mData;
	}

	// ���������ȡѧ������
	public List<Student> getStudents(String queryStr) {
		List<Student> questions = new ArrayList<Student>();
		URL url = null;
		try {
			url = new URL("http://" + ip
					+ ":8080/homeworkServer/servlet/getStudents");
			HttpURLConnection connection = (HttpURLConnection) url
					.openConnection();
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setConnectTimeout(10000);
			connection.setReadTimeout(10000);
			connection.setRequestMethod("POST");
			DataOutputStream outobj = new DataOutputStream(
					connection.getOutputStream());

			outobj.writeUTF(queryStr);
			outobj.flush();
			outobj.close();
			ObjectInputStream ois = new ObjectInputStream(
					connection.getInputStream());

			Student obj = (Student) ois.readObject();
			while (!obj.getStudentId().equals("00000")) {
				// System.out.println(obj.getQuestion());
				questions.add(obj);
				obj = (Student) ois.readObject();
			}
			ois.close();
			connection.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
		return questions;
	}

	public void networkPolicy() {
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
				.detectDiskReads().detectDiskWrites().detectNetwork() // ��������滻ΪdetectAll()
																		// �Ͱ����˴��̶�д������I/O
				.penaltyLog() // ��ӡlogcat����ȻҲ���Զ�λ��dropbox��ͨ���ļ�������Ӧ��log
				.build());
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
				.detectLeakedSqlLiteObjects() // ̽��SQLite���ݿ����
				.penaltyLog() // ��ӡlogcat
				.penaltyDeath().build());
	}
}
