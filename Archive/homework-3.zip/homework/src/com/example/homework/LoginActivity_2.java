package com.example.homework;

import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.gdufs.entity.Student;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity_2 extends Activity {
	TextView userid, password, log_info;
	Button login_ok;
	String ip = "192.168.1.102";
	private ProgressDialog pd;

	// ����Handler����
	private Handler handler = new Handler() {
		@Override
		// ������Ϣ���ͳ�����ʱ���ִ��Handler���������
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			Student student = (Student) msg.obj;
			if (student.getStudentId().equals("fail")) {
				log_info.setText("�û��������");
			} else {
				log_info.setText("��¼�ɹ���");
			}
			// ֻҪִ�е�����͹رնԻ���
			pd.dismiss();
			Intent intent = new Intent(LoginActivity_2.this,
					StudentsActivity.class);
			startActivity(intent);
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		Intent intent = new Intent(LoginActivity_2.this,
				StudentsActivity.class);
		startActivity(intent);
		
		userid = (TextView) this.findViewById(R.id.login_userid);
		password = (TextView) this.findViewById(R.id.login_password);
		log_info = (TextView) this.findViewById(R.id.login_errInfo);
		login_ok = (Button) this.findViewById(R.id.login_ok);
		login_ok.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// �õ��û���������ı༭��
				loginThread();

			}
		});
	}

	private void loginThread() {

		// ����һ�����ؽ�����
		pd = ProgressDialog.show(LoginActivity_2.this, "��¼", "���ڵ�¼��");
		new Thread() {
			public void run() {
				// ������ִ�г���ʱ����
				Student student = login(userid.getText().toString().trim(), password
						.getText().toString().trim());
				Message message = Message.obtain();
				message.obj = student;
				// ִ����Ϻ��handler����һ����Ϣ
				handler.sendMessage(message);
			}
		}.start();
	}

	public Student login(String stid, String pwd) {
		Student result = null;
		URL url = null;
		try {
			url = new URL("http://" + ip
					+ ":8080/edu/servlet/StudentLogin");
			HttpURLConnection connection = (HttpURLConnection) url
					.openConnection();
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setConnectTimeout(10000);
			connection.setReadTimeout(10000);
			connection.setRequestMethod("POST");
			ObjectOutputStream outobj = new ObjectOutputStream(
					connection.getOutputStream());
			Student st = new Student();
			st.setStudentId(stid);
			st.setPassword(pwd);
			st.setLatitude(23);
			st.setLongitude(24);
			st.setIp("");
			// st.setTelephone("1239");
			// st.setCourseId("XX31490-199710822-2");
			outobj.writeObject(st);
			outobj.flush();
			outobj.close();
			ObjectInputStream ois = new ObjectInputStream(
					connection.getInputStream());
			result = (Student) ois.readObject();
			ois.close();
			connection.disconnect();
		} catch (Exception e) {
			userid.setText(e.toString());
			e.printStackTrace();
		} finally {

		}
		return result;
	}
}
